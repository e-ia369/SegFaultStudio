#include <stdlib.h>
#include "include/save.h"
#include "include/utils.h"
#include "include/village.h"

void print_saves(Save *head, int count)
{
    if (count <= 0)
    {
        printf("No saved games.\n");
        return;
    }
    printf("\n||| SAVED GAMES |||\n");
    for (int i = 1; i <= count; i++)
    {
        Save *s = get_save(head, i);
        printf("[%d] %s, %d HP, %d COINS, %d ITEMS, %d COMPLETED MISSIONS\n", 
            i, s->timestamp, s->hero.hp, s->hero.coins, s->hero.items, s->hero.missions_completed);
    }
}

void add_save(Save **head, Hero hero)
{
    Save *new_save = (Save *)malloc(sizeof(Save));
    
    new_save->hero = hero;
    get_timestamp(new_save->timestamp);
    new_save->next = *head;

    *head = new_save;
}

void delete_save(Save **head, int index)
{
    if (*head == NULL)
        return;
    if (index == 1) // (first node case)
    {
        Save *tmp = *head;
        *head = tmp->next;
        free(tmp);
        return;
    }

    // Find the node before the one to delete
    Save *prev = *head;
    for (int i = 1; prev != NULL && i < index - 1; i++)
        prev = prev->next;
    if (prev == NULL || prev->next == NULL)
        return;

    // Delete the node
    Save *deleted = prev->next;
    prev->next = deleted->next; // make a "hole"
    free(deleted);
}

Save *get_save(Save *head, int index)
{
    Save *curr = head;
    for (int i = 1; curr != NULL && i < index; i++)
        curr = curr->next;
    return curr;
}

int count_saves(Save *head)
{
    int c = 0;
    while (head)
    {
        c++;
        head = head->next;
    }
    return c;
}

void load_save(Save **head)
{
    if (!(*head))
    {
        printf("\nNo saved games found in memory.\n");
        return;
    }
    int count = count_saves(*head);
    print_saves(*head, count);

    int index = ask_int("Select a save", 1, count);
    int action = ask_int("1. Load, 2. Delete", 1, 2);

    if (action == 1)
    {
        Save *s = get_save(*head, index);
        if (s)
        {
            printf("Loading save...\n");
            Hero h = s->hero;
            village_menu(&h, head);
        }
    }
    else if (action == 2)
    {
        if (ask_confirm("Are you sure?"))
        {
            delete_save(head, index);
            printf("\nSave deleted.\n");
        }
    }
}
