/**
 * @file fight.c
 * @brief Implementation of combat system mechanics.
 */

#include "include/fight.h"
#include "include/utils.h"
#include <stdio.h>
#include <stdlib.h>

/**
 * @brief Recursive helper to check if n is in padovan sequence.
 * we start counting through sequence till we reach (true) or surpass (false) n
 * @param n The number to check.
 * @param a P(n-3)
 * @param b P(n-2)
 * @param c P(n-1)
 * @return 1 if n is in the sequence, 0 if not.
 */
int is_padovan_rec(int n, int a, int b, int c)
{
    int next = a + b;

    if (next == n)
        return 1; // found n, then n in padovan

    if (next > n)
        return 0; // surpassed n, then n not in padovan

    return is_padovan_rec(n, b, c, next);
}

/**
 * @brief Wrapper of is_padovan_rec() to check if n is in padovan sequence.
 * (We need this just to avoid passing initial values every time)
 * @param n The number to check.
 * @return 1 n is in sequence, 0 if not.
 */
int is_padovan(int n)
{
    if (n == 1)
        return 1; // (first 3 terms are 1)
    if (n < 1)
        return 0; // (not defined for n < 1)

    return is_padovan_rec(n, 1, 1, 1);
}

int fight(Hero *hero, int enemy_n)
{
    const char *name = "";
    int fatal_strike = 0, dmg = 0, coins = 0;

    switch (enemy_n)
    {
    case 1:
        name = "Wild Dog";
        fatal_strike = 2;
        dmg = 1;
        coins = 0;
        break;
    case 2:
        name = "Goblin";
        fatal_strike = 3;
        dmg = 2;
        coins = 2;
        break;
    case 3:
        name = "Skeleton";
        fatal_strike = 4;
        dmg = 2;
        coins = 4;
        break;
    case 4:
        name = "Orc";
        fatal_strike = 3;
        dmg = 4;
        coins = 6;
        break;
    case 5:
        name = "Orc General";
        fatal_strike = (hero->has_hero_sword) ? 5 : 6;
        dmg = 3;
        coins = 12;
        break;
    case 6:
        name = "Bat";
        fatal_strike = 2;
        dmg = 2;
        coins = 1;
        break;
    case 7:
        name = "Zombie";
        fatal_strike = 3;
        dmg = 2;
        coins = 2;
        break;
    case 8:
        name = "Phantom";
        fatal_strike = 5;
        dmg = 2;
        coins = 4;
        break;
    case 9:
        name = "Greater Vampire";
        fatal_strike = 4;
        dmg = 4;
        coins = 7;
        break;
    case 10:
        name = "Guardian Demon";
        fatal_strike = 4;
        dmg = 6;
        coins = 10;
        break;
    case 11:
        name = "Ancient Dragon";
        fatal_strike = 5;
        dmg = 10;
        coins = 12;
        break;
    }

    printf("\nYou encountered a %s!\n", name);
    printf("!!! BATTLE STARTED !!!\n");
    while (hero->hp > 0)
    {
        int d = roll(6);
        int buff = hero->has_hero_sword ? 2 : (hero->has_sword ? 1 : 0);
        int atk = d + buff;
        printf("\nYou rolled a %d + %d (weapon) = %d ATK\n", d, buff, atk);

        if (atk >= fatal_strike)
        {
            printf("FATAL STRIKE! The %s is defeated!\n", name);
            printf("You got %d coins.\n", coins);

            hero->coins += coins;
            if (enemy_n == 5)
                hero->generals_killed++;
            if (enemy_n == 9)
                hero->vampire_killed = 1;
            if (enemy_n == 10)
            {
                hero->has_key = 1;
                hero->items++;
                printf("The demon dropped the key to the dark lord's castle!\n");
            }
            if (enemy_n == 11)
            {
                hero->dragon_killed = 1;
                hero->has_hero_sword = 1;
                hero->has_sword = 0;
                hero->items++;
                printf("The dragon dropped the hero's sword!\n");
            }
            return 1;
        }
        else
        {
            printf("YOU MISSED! (Needed %d or more)\n", fatal_strike);

            if (enemy_n == 11) // dragon
            {
                int n = roll(500);
                printf("The Ancient Dragon speaks before attacking...\n");
                printf("Does the number %d", n);
                int ans = ask_confirm(" belong to the Padovan sequence?");
                if (ans == is_padovan(n))
                {
                    printf("The Dragon approves (0 dmg this turn).\n");
                    continue;
                }
                else
                    printf("Wrong!\n");
            }

            printf("The %s counter-attacks!\n", name);
            if (hero->has_armor && dmg > 0)
            {
                printf("You took %d damage. (Armor blocked 1 DMG)\n", dmg - 1);
                hero->hp -= (dmg - 1);
            }
            else
            {
                printf("You took %d damage.\n", dmg);
                hero->hp -= dmg;
            }

            if (hero->hp <= 0)
                hero->hp = 0;
            printf("Remaining HP: %d/%d\n", hero->hp, MAX_HP);
        }
    }
    return 0;
}
