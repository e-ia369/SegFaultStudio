/**
 * @file main.c
 * @brief Entry point.
 * 
 * Handles the Main Menu, Cheat Menu, and memorizes saves.
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include "include/hero.h"
#include "include/save.h"
#include "include/utils.h"
#include "include/village.h"

Save *saves = NULL; /**< Global head of the save list. */


/**
 * @brief Handles cheat menu logic.
 */
void cheat_menu()
{
    printf("\n$$$ CHEAT MENU $$$\n");
    if (!saves)
    {
        printf("No saves available to activate cheats on.\n");
        return;
    }
    int count = count_saves(saves);
    print_saves(saves, count);

    int i = ask_int("Select save to activate cheats on", 1, count);
    Save *s = get_save(saves, i);

    if (s)
    {
        printf("1. Set HP\n2. Set Coins\n3. Unlock Final Mission\n");
        int a = ask_int("Edit", 1, 3);
        if (a == 1)
        {
            printf("New HP: ");
            scanf("%d", &s->hero.hp);
            remove_newline();
        }
        if (a == 2)
        {
            printf("New Coins: ");
            scanf("%d", &s->hero.coins);
            remove_newline();
        }
        if (a == 3)
        {
            s->hero.swamp_done = 1;
            s->hero.mansion_done = 1;
            s->hero.cave_done = 1;
            s->hero.missions_completed = 3;
            s->hero.has_key = 1;
            printf("All missions cleared.\n");
        }
    }
}

/**
 * @brief Main program entry + cheat menu unlocking logic (konami code).
 * Initializes srand(), outputs main game menu, and checks konami code.
 */
int main()
{
    srand(time(NULL));
    bool cheats_unlocked = false;

    char konami_code[] = {'w', 'w', 's', 's', 'a', 'd', 'a', 'd', 'b', 'a', ' '};
    int codeLength = 11;

    int i = 0;
    while (1)
    {
        printf("\n################################\n");
        printf("#    DUNGEONS AND SEGFAULTS    #\n");
        printf("################################\n");
        printf("1. New Game\n");
        printf("2. Load Game\n");
        if (cheats_unlocked)
        {
            printf("3. Cheats\n");
            printf("Choose an action [1-3]: ");
            char c;
            scanf("%c", &c);
            remove_newline();
            if (c == '1')
            {
                Hero hero;
                init_hero(&hero);
                village_menu(&hero, &saves);
            }
            else if (c == '2')
                load_save(&saves);
            else if (c == '3')
                cheat_menu();
        }
        while (!cheats_unlocked)
        {
            printf("Choose an action [1-2]: ");
            char c = getchar();
            char enter = getchar();

            if (c == '1')
            {
                Hero hero;
                init_hero(&hero);
                village_menu(&hero, &saves);
                break;
            }
            else if (c == '2')
            {
                load_save(&saves);
                break;
            }

            if (konami_code[i] == c)
                i++;
            else
                i = 0; // reset counter if wrong input

            if (i == codeLength)
            {
                cheats_unlocked = true;
                printf("Cheat menu unlocked!\n");
            }
        }
    }
    return 0;
}
