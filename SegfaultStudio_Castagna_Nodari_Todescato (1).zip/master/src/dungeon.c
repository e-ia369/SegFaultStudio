/**
 * @file dungeon.c
 * @brief Implementation of dungeon generation and exploration.
 */

#include "include/dungeon.h"
#include "include/fight.h"
#include "include/shop.h"
#include "include/traps.h"
#include "include/utils.h"


/**
 * @brief Generates procedurally 10 dungeon rooms and returns the minimal valid length of the dungeon.
 * Forces presence of mandatory enemies based on dungeon type, only if they are not generated randomly within the first 10 rolls.
 * @param rooms Array of integers to store room ids.
 * @param type Dungeon type.
 * @return The real number of rooms of the dungeon.
 */
int dungeon_gen(int *rooms, int type)
{
    for (int i = 0; i < 10; i++)
        rooms[i] = roll(6);

    if (type == 1) // Swamp
    {
        rooms[7] = 6;
        rooms[8] = 6;
        rooms[9] = 6;

        int generals = 0;
        for (int i = 0; i < 10; i++)
        {
            if (rooms[i] == 6)
                generals++;
            if (generals >= 3)
                return i + 1;
        }
        // in this way we always have at least 3 generals
        // but if they are generated sooner than our last 3 rooms, we return
    }
    else if (type == 2) // Mansion
    {
        rooms[8] = 5;
        rooms[9] = 6;

        int vampire = 0;
        for (int i = 0; i < 10; i++)
        {
            if (rooms[i] == 5)
            {
                vampire = i;
                break;
            }
        }
        int demon = 0;
        for (int i = 0; i < 10; i++)
        {
            if (rooms[i] == 6)
            {
                demon = i;
                break;
            }
        }
        return (vampire > demon ? vampire : demon) + 1;
        // in this way we take the max index between vampire and demon
        // so we are sure to have both in the dungeon with minimum length
    }
    else if (type == 3) // Cave
    {
        rooms[9] = 6;
        for (int i = 0; i < 10; i++)
        {
            if (rooms[i] == 6) // as soon as we find the dragon, we are ok
                return i + 1;
        }
    }
}

void dungeon_run(Hero *hero, int type)
{
    int rooms[10];
    int dungeon_length = dungeon_gen(rooms, type);

    const char *dungeon_names[] = {"", "Rotting Swamp", "Haunted Mansion", "Crystal Cave"};
    printf("\nEntering... %s\n", dungeon_names[type]);

    int room = 0;
    while (room < dungeon_length && hero->hp > 0)
    {
        printf("\nROOM %d of %d [%d HP]\n", room + 1, dungeon_length, hero->hp);
        printf("1. Explore Room\n2. Open Shop\n3. Check Inventory\n4. Return to village (50 coins if not completed)\n");

        int act = ask_int("Choose action", 1, 4);
        if (act == 2)
            shop(hero);
        else if (act == 3)
            inventory(hero);
        else if (act == 4)
        {
            int done = (type == 1 && hero->generals_killed >= 3) ||
                       (type == 2 && hero->vampire_killed && hero->has_key) ||
                       (type == 3 && hero->dragon_killed);
            if (done)
            {
                hero->missions_completed++;
                printf("\nMISSION COMPLETED! You leave the dungeon victorious.\n");
                if (type == 1)
                    hero->swamp_done = 1;
                if (type == 2)
                    hero->mansion_done = 1;
                if (type == 3)
                    hero->cave_done = 1;
                return;
            }
            if (hero->coins >= 50)
            {
                hero->coins -= 50;
                printf("\nYou payed to complete the mission! (-50 coins)\n");
                if (type == 1)
                {
                    hero->swamp_done = 1;
                    hero->generals_killed = 3;
                }
                if (type == 2)
                {
                    hero->mansion_done = 1;
                    hero->vampire_killed = 1;
                    hero->has_key = 1;
                }
                if (type == 3)
                {
                    hero->cave_done = 1;
                    hero->dragon_killed = 1;
                }

                // NOTE: The "done" variables are equivalent to mission completion criteria,
                // they are used just for clarity.
                // For that reason, in this case (pay to complete) we force them.
                return;
            }
            else
                printf("\nYou need 50 coins to escape! (you have %d coins)\n", hero->coins);
        }
        else if (act == 1)
        {
            int r = rooms[room];
            
            // we make the same indexes work with both traps and fights
            // since they are 6-based rolls, we need to map them (with sums)

            if (type == 1) // Swamp
            {
                if (r >= 1 && r <= 4)
                    fight(hero, r);
                else if (r == 5)
                    trap(hero, 1);
                else if (r == 6)
                    fight(hero, 5);
            }
            else if (type == 2) // Mansion
            {
                if (r == 1)
                    trap(hero, 2);
                else if (r >= 2 && r <= 6)
                    fight(hero, r + 4); 
            }
            else if (type == 3) // Cave
            {
                if (r == 1)
                    printf("\nThe room is empty.\n");
                else if (r >= 2 && r <= 5)
                    trap(hero, r + 1);
                else if (r == 6)
                    fight(hero, 11);
            }

            if (hero->hp <= 0)
            {
                printf("\nGAME OVER!\n");
                printf("You died in the %s.\n", dungeon_names[type]);
            }
            room++;
        }
    }
    if (hero->hp > 0)
    {
        hero->missions_completed++;
        printf("\nYou cleared the dungeon and completed the mission!\n");
        printf("One step closer to the dark lord!\n");

        // here we don't need to check if the mission is done,
        // because dungeon generation forces mission completion
        if (type == 1)
            hero->swamp_done = 1;
        if (type == 2)
            hero->mansion_done = 1;
        if (type == 3)
            hero->cave_done = 1;
    }
}
