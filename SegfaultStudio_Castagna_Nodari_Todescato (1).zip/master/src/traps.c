#include <stdlib.h>
#include "include/traps.h"
#include "include/utils.h"

void trap(Hero *hero, int type)
{
    int d;
    printf("\n??? IT'S A TRAP ???\n");
    switch (type)
    {
    case 1:
        d = roll(6);
        hero->hp -= d;
        printf("You stepped into a Poisonous Bog!\n");
        printf("-%d HP\n", d);
        break;
    case 2:
        hero->hp -= 3;
        printf("A Dark Hatch opens beneath you!\n");
        printf("-3 HP\n");
        break;
    case 3:
        hero->hp -= 2;
        printf("Sharp crystals fall from the ceiling!\n");
        printf("-2 HP\n");
        break;
    case 4:
        hero->coins -= 3;
        if (hero->coins < 0)
            hero->coins = 0;
        printf("You cross an Unsafe Bridge. -3 coins!\n");
        printf("Current coins: %d\n", hero->coins);
        break;
    case 5:
        printf("You find a Mysterious Chest...\n");
        if (roll(2) == 1)
        {
            hero->coins += 10;
            printf("Nice!\n+10 coins!\n");
            printf("Current coins: %d\n", hero->coins);
        }
        else
        {
            hero->hp -= 2;
            printf("It's a mimic!\n-2 HP\n");
        }
        break;
    case 6:
        d = roll(6);
        hero->hp -= d;
        printf("You slip off a Steep Cliff!\n");
        printf("-%d HP\n", d);
        break;
    }
    if (hero->hp < 0)
        hero->hp = 0;
    printf("Remaining HP: %d\n", hero->hp);
}
