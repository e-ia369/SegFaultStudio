/**
 * @file boss.h
 * @brief Logic for the final mission (Dark Lord fight).
 */

#ifndef BOSS
#define BOSS

#include "hero.h"

/**
 * @brief Starts the Rock-Paper-Scissors final mission against the Dark Lord.
 * @param hero Pointer to the Hero.
 */
void final_mission(Hero *hero);

#endif
