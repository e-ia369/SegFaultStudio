/**
 * @file save.h
 * @brief Implements game save structure and related functions.
 */

#ifndef SAVE
#define SAVE

#include "hero.h"

/**
 * @struct Save
 * @brief Defines game save structure (implemented with linked list).
 */
typedef struct Save
{
    Hero hero;
    char timestamp[40];
    struct Save *next;
} Save;

/**
 * @brief Prints available game saves.
 * @param head Head of the saves list.
 * @param count The number of saves to print.
 */
void print_saves(Save *head, int count);

/**
 * @brief Adds a new save node to the start of the list.
 * @param head Double pointer to the head of the saves list (it needs to be modified).
 * @param hero The Hero data (game state) to save.
 */
void add_save(Save **head, Hero hero);

/**
 * @brief Deletes a save node at a specific index.
 * @param head Double pointer to the head of the saves list (it needs to be modified).
 * @param index Index of the save to remove (1-based).
 */
void delete_save(Save **head, int index);

/**
 * @brief Gets a specific saves list node at a given index.
 * @param head Head of the save list.
 * @param index Index of the save to get (1-based).
 * @return Pointer to the selected saves list node.
 */
Save *get_save(Save *head, int index);

/**
 * @brief Counts the total number of saves in the list.
 * @param head Pointer to the head of the save list.
 * @return Integer count of nodes.
 */
int count_saves(Save *head);

/**
 * @brief Handles game saves loading menu.
 * Doesn't load directly by a given index, but prints a menu to make the user choose.
 * @param head Double pointer to the head of the save list (doesn't directly modify it, 
 * but passes it to village_menu and potentially delete_save, so we need double pointer).
 */
void load_save(Save **head);

#endif
