/**
 * @file village.h
 * @brief Village menu logic.
 */

#ifndef VILLAGE
#define VILLAGE

#include "hero.h"

struct Save;

/**
 * @brief Handles village menu IO and basic logic.
 * @param hero Pointer to the Hero (game state).
 * @param saves Double pointer to the save list (because contains add_save()).
 */
void village_menu(Hero *hero, struct Save **saves);

#endif
