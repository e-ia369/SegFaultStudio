/**
 * @file traps.h
 * @brief Traps implementation.
 */

#ifndef TRAPS
#define TRAPS

#include "hero.h"

/**
 * @brief Triggers trap based on type.
 * @param hero Pointer to the Hero.
 * @param type Number of the trap type.
 */
void trap(Hero *hero, int type);

#endif
