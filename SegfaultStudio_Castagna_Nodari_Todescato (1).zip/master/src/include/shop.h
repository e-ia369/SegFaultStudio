/**
 * @file shop.h
 * @brief Implements shop menu.
 */

#ifndef SHOP
#define SHOP

#include "hero.h"

/**
 * @brief Opens the shop menu.
 * @param hero Pointer to the Hero (to change items).
 */
void shop(Hero *hero);

#endif
