/**
 * @file fight.h
 * @brief Enemy combat mechanics implementation.
 */

#ifndef FIGHT
#define FIGHT

#include "hero.h"

/**
 * @brief Triggers a battle with a specific enemy, by id.
 * @param hero Pointer to the Hero.
 * @param enemy_n The unique number of the enemy type (id).
 * @return 1 if the hero wins, 0 if defeated.
 */
int fight(Hero *hero, int enemy_n);

#endif
