/**
 * @file hero.h
 * @brief Defines the Hero structure and basic hero functions.
 */

#ifndef HERO
#define HERO

#include <stdio.h>
#include <string.h>

#define MAX_HP 20

/**
 * @struct Hero
 * @brief Defines Hero attributes, (contains complete game state).
 */
typedef struct
{
    int hp;
    int coins;
    int items;

    int has_sword;
    int has_hero_sword;
    int has_armor;
    int has_key;

    int missions_completed;
    int swamp_done;
    int mansion_done;
    int cave_done;

    int generals_killed;
    int vampire_killed;
    int dragon_killed;
} Hero;

/**
 * @brief Initializes the hero with default stats (everything to 0 except HP to MAX_HP).
 * @param hero Pointer to the Hero structure to init.
 */
void init_hero(Hero *hero);

/**
 * @brief Prints the hero's current status and inventory.
 * @param hero Pointer to the Hero structure to print inventory of.
 */
void inventory(Hero *hero);

#endif
