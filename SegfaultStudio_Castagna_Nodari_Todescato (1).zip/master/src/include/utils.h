/**
 * @file utils.h
 * @brief Common use utility functions for IO, randoms, and time.
 */

#ifndef UTILS
#define UTILS

/**
 * @brief Clears stdin (removes characters from input buffer until a newline is found).
 */
void remove_newline();

/**
 * @brief Simulates dice rolling of given sides.
 * @param sides Number of sides of the dice.
 * @return Dice throwing result.
 */
int roll(int sides);

/**
 * @brief Gets the current time formatted as a string.
 * @param timestamp String to store the result (could have used UNIX time but it's simpler like this).
 */
void get_timestamp(char *timestamp);

/**
 * @brief Asks for a Yes/No confirmation (widely used in the game).
 * @param msg The question to display to the user.
 * @return 1 if user types 'y', 0 for every other char.
 */
int ask_confirm(const char *msg);

/**
 * @brief Asks for an integer within a specific range, also handling invalid input.
 * @param msg Message to display.
 * @param min Minimum valid value.
 * @param max Maximum valid value.
 * @return Validated integer entered in input.
 */
int ask_int(const char *msg, int min, int max);

#endif
