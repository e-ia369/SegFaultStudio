/**
 * @file dungeon.h
 * @brief Logic for dungeon exploration and dungeon implementation.
 */

#ifndef DUNGEON
#define DUNGEON

#include "hero.h"

/**
 * @brief Starts the main dungeon gameplay (based on type).
 * @param hero Pointer to the Hero.
 * @param type Dungeon type (or id).
 */
void dungeon_run(Hero *hero, int type);

#endif
