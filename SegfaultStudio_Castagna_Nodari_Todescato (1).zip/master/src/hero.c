#include "include/hero.h"

void init_hero(Hero *hero)
{
    memset(hero, 0, sizeof(Hero)); // we can set everything to zero based on struct definition
    hero->hp = MAX_HP; // apart from hp, which starts at max
}

void inventory(Hero *hero)
{
    printf("\n||| INVENTORY |||\n");
    printf("Health:  %-2d/%-2d\n", hero->hp, MAX_HP);
    printf("Coins:   %-4d\n", hero->coins);
    printf("Items:   %-4d\n", hero->items);
    printf("Equipment:\n");
    if (hero->has_hero_sword)
        printf("  -Hero's Sword (+2 ATK)\n");
    else if (hero->has_sword)
        printf("  -Steel Sword (+1 ATK)\n");
    else
        printf("  -No Sword (Base ATK)\n");
    if (hero->has_armor)
        printf("  -Iron Armor (-1 DMG Taken)\n");
    else
        printf("  -No Armor (Base DMG Taken)\n");

    if (hero->has_key)
        printf("  -Key to Dark Lord's Castle\n");
}
