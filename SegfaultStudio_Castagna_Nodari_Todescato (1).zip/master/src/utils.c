#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "include/utils.h"

void remove_newline()
{
    while (getchar() != '\n');
    // to avoid leftover newlines in input buffer
}

int roll(int sides)
{
    return (rand() % sides) + 1;
}

void get_timestamp(char *timestamp)
{
    time_t now = time(NULL);
    struct tm t = *localtime(&now);
    sprintf(timestamp, "%02d:%02d:%02d", t.tm_hour, t.tm_min, t.tm_sec);
}

int ask_confirm(const char *msg)
{
    printf("%s [Yes/No] (y/n): ", msg);
    char c;
    scanf(" %c", &c);
    remove_newline();
    return (c == 'y');
}

int ask_int(const char *msg, int min, int max)
{
    int n;
    while (1)
    {
        printf("%s [%d-%d]: ", msg, min, max);

        int read = scanf("%d", &n);
        remove_newline();
        
        if (read == 1 && n >= min && n <= max) // (we need to check if scanf read a number, or n could not be set)
            return n;

        printf("Hey! Enter a number between %d and %d!\n", min, max);
    }
}