#include "include/shop.h"
#include "include/utils.h"

void shop(Hero *hero)
{
    printf("\n$$$ SHOP MENU $$$\n");
    printf("1. Health Potion (4 Coins)  [Restores 1-6 HP] (immediately)\n");
    printf("2. Steel Sword   (5 Coins)  [+1 Attack]\n");
    printf("3. Iron Armor    (10 Coins) [-1 Damage Taken]\n");
    printf("4. Leave Shop\n");

    printf("You have %d Coins\n", hero->coins);

    int c = ask_int("What do you want to buy?", 1, 4);

    if (c == 4)
    {
        printf("bye!\n");
        return;
    }

    if (c == 1)
    {
        if (hero->hp >= MAX_HP)
            printf("You already have max HP!\n");
        else if (hero->coins >= 4)
        {
            hero->coins -= 4;
            int heal = roll(6);
            hero->hp += heal;
            if (hero->hp > MAX_HP)
                hero->hp = MAX_HP;
            hero->items++;
            printf("You drink the potion. +%d HP!\n", heal);
        }
        else
            printf("Not enough coins!\n");
    }
    else if (c == 2)
    {
        if (hero->has_sword || hero->has_hero_sword)
        {
            printf("You already have a sword!\n");
        }
        else if (hero->coins >= 5)
        {
            hero->coins -= 5;
            hero->has_sword = 1;
            hero->items++;
            printf("You bought the Steel Sword! +1 ATK!\n");
        }
        else
            printf("Not enough coins!\n");
    }
    else if (c == 3)
    {
        if (hero->has_armor)
        {
            printf("You already have armor!\n");
        }
        else if (hero->coins >= 10)
        {
            hero->coins -= 10;
            hero->has_armor = 1;
            hero->items++;
            printf("You bought the Iron Armor! -1 DMG taken!\n");
        }
        else
            printf("Not enough coins!\n");
    }
}
