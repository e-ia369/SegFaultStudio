#include "include/boss.h"
#include "include/utils.h"
#include <stdlib.h>

void final_mission(Hero *hero)
{
    printf("\n### FINAL MISSION! ###\n");
    printf("You finally face the Dark Lord!\n");

    int rounds = 0;
    int hero_score = 0;
    char *moves[] = {"", "Shield", "Magic", "Sword"};

    while (rounds < 5 && hero_score < 3)
    {
        printf("\nFinal Fight | Round %d of 5 | You %d - Dark Lord %d.\n", rounds + 1, hero_score, rounds - hero_score);
        printf("Available moves:\n  1. Shield \n  2. Magic \n  3. Sword\n");
        
        int hero_move = ask_int("What do you choose? ", 1, 3);
        int lord_move = roll(3);
        printf("You used %s.\n", moves[hero_move]);
        printf("Dark Lord used %s.\n", moves[lord_move]);

        if (hero_move == lord_move)
        {
            printf("Draw! Rerolling round...\n");
            continue;
        }

        if ((hero_move == 1 && lord_move == 3) || (hero_move == 2 && lord_move == 1) || (hero_move == 3 && lord_move == 2))
        {
            printf("You won this round!\n");
            hero_score++;
        }
        else
        {
            printf("The dark lord won this round!\n");
        }
        rounds++;
    }

    if (hero_score >= 3)
    {
        printf("\n:) GG! :)\n");
        printf("You defeated the Dark Lord and saved the world!\n");
        printf("Thanks for playing!\n");
        exit(0);
    }
    else
    {
        printf("\nGAME OVER!\n");
        printf("The Dark Lord defeated you, try again!\n");
        hero->hp = 0;
    }
}
