#include "include/village.h"
#include "include/dungeon.h"
#include "include/boss.h"
#include "include/save.h"
#include "include/utils.h"

void village_menu(Hero *hero, Save **saves)
{
    while (hero->hp > 0)
    {
        printf("\n||| VILLAGE MENU |||\n");
        printf("1. Start Mission\n2. Rest (Restore HP)\n3. Inventory\n4. Save Game\n5. Exit Game\n");

        int action = ask_int("Choose an action", 1, 5);
        if (action == 1)
        {
            printf("\nAVAILABLE MISSIONS\n");
            printf("0. Cancel\n");
            if (!hero->swamp_done)
                printf("1. Rotting Swamp\n");
            else
                printf("1. Rotting Swamp [done]\n");

            if (!hero->mansion_done)
                printf("2. Haunted Mansion\n");
            else
                printf("2. Haunted Mansion [done]\n");

            if (!hero->cave_done)
                printf("3. Crystal Cave\n");
            else
                printf("3. Crystal Cave [done]\n");

            // missions are still visible but not playable, just for aesthetic purpose

            int mission = 0;
            if (hero->swamp_done && hero->mansion_done && hero->cave_done && hero->has_key)
            {
                printf("\nFINAL MISSION\n");
                printf("4. Dark Lord's Castle\n");
                mission = ask_int("Select Mission", 0, 4);
            }
            else
                mission = ask_int("Select Mission", 0, 3);

            if (mission == 1 && !hero->swamp_done)
                dungeon_run(hero, 1);
            else if (mission == 2 && !hero->mansion_done)
                dungeon_run(hero, 2);
            else if (mission == 3 && !hero->cave_done)
                dungeon_run(hero, 3);
            else if (mission == 4)
                // here we don't need to check if unlocked, handled inside ask_int()
                final_mission(hero);
            else if (mission != 0)
                printf("Mission already completed!\n");
        }
        else if (action == 2)
        {
            hero->hp = MAX_HP;
            printf("\nYou sleep. HP restored to %d.\n", MAX_HP);
        }
        else if (action == 3)
            inventory(hero);

        else if (action == 4)
        {
            add_save(saves, *hero);
            printf("\nGame saved to memory.\n");
        }
        else if (action == 5)
            if (ask_confirm("Unsaved progress will be lost, are you sure?"))
                return;
    }
}
