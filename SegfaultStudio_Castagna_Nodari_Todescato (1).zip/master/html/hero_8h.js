var hero_8h =
[
    [ "Hero", "structHero.html", null ],
    [ "init_hero", "hero_8h.html#a924299a138f1ea64fa4ace836031c711", null ],
    [ "inventory", "hero_8h.html#a8935b14e890cb1bfbe8f7759bd3bac87", null ]
];