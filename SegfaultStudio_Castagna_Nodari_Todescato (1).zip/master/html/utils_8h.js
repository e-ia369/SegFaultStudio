var utils_8h =
[
    [ "ask_confirm", "utils_8h.html#abb6627b27757f5e74fb902d464abc0b4", null ],
    [ "ask_int", "utils_8h.html#aab9d0d84a1692de099a9c3be28a49ab9", null ],
    [ "get_timestamp", "utils_8h.html#acb913d01b2b5417fde5ed318d9fda2a7", null ],
    [ "remove_newline", "utils_8h.html#af1e10b4b1d0be8f0450090ac1f3da9fe", null ],
    [ "roll", "utils_8h.html#a54025cc710d14c040231ab8f18c16541", null ]
];