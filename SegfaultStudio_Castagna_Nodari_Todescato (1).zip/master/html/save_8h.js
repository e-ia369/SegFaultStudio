var save_8h =
[
    [ "Save", "structSave.html", null ],
    [ "add_save", "save_8h.html#a8528111c8dabda825c4e4921c4e1c641", null ],
    [ "count_saves", "save_8h.html#aba955ba7b86394c560634d1d20ade6e1", null ],
    [ "delete_save", "save_8h.html#afc3fea3c522584688bbdc3e237b9cfd1", null ],
    [ "get_save", "save_8h.html#a9b280356106cbc2adc255b32f8229d4b", null ],
    [ "load_save", "save_8h.html#a774498701f1ff8d8c9384592912798e5", null ],
    [ "print_saves", "save_8h.html#a6009215f68036cf6b519711e24605d00", null ]
];