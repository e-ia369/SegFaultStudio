var searchData=
[
  ['saves_0',['saves',['../main_8c.html#a9a831f38dd16b5283b83a3b716374156',1,'main.c']]]
];
