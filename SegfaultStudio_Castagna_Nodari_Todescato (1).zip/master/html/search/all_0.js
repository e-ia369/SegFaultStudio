var searchData=
[
  ['add_5fsave_0',['add_save',['../save_8h.html#a8528111c8dabda825c4e4921c4e1c641',1,'save.c']]],
  ['ask_5fconfirm_1',['ask_confirm',['../utils_8h.html#abb6627b27757f5e74fb902d464abc0b4',1,'utils.c']]],
  ['ask_5fint_2',['ask_int',['../utils_8h.html#aab9d0d84a1692de099a9c3be28a49ab9',1,'utils.c']]]
];
