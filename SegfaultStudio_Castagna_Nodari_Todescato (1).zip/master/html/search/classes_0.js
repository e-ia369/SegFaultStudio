var searchData=
[
  ['hero_0',['Hero',['../structHero.html',1,'']]]
];
