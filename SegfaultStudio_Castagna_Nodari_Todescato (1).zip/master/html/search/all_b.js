var searchData=
[
  ['remove_5fnewline_0',['remove_newline',['../utils_8h.html#af1e10b4b1d0be8f0450090ac1f3da9fe',1,'utils.c']]],
  ['roll_1',['roll',['../utils_8h.html#a54025cc710d14c040231ab8f18c16541',1,'utils.c']]]
];
