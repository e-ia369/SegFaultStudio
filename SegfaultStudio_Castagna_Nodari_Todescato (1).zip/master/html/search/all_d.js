var searchData=
[
  ['trap_0',['trap',['../traps_8h.html#a438548268cec11d3e39d637dc1e75071',1,'traps.c']]],
  ['traps_2eh_1',['traps.h',['../traps_8h.html',1,'']]]
];
