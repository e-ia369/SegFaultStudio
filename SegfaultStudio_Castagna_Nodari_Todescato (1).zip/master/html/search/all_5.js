var searchData=
[
  ['get_5fsave_0',['get_save',['../save_8h.html#a9b280356106cbc2adc255b32f8229d4b',1,'save.c']]],
  ['get_5ftimestamp_1',['get_timestamp',['../utils_8h.html#acb913d01b2b5417fde5ed318d9fda2a7',1,'utils.c']]]
];
