var searchData=
[
  ['fight_0',['fight',['../fight_8c.html#abd4ecd90fd4bf7772bf540aba9131adb',1,'fight(Hero *hero, int enemy_n):&#160;fight.c'],['../fight_8h.html#abd4ecd90fd4bf7772bf540aba9131adb',1,'fight(Hero *hero, int enemy_n):&#160;fight.c']]],
  ['final_5fmission_1',['final_mission',['../boss_8h.html#afa850cc8fe0e51bf6e9c3bfa15e9c4f6',1,'boss.c']]]
];
