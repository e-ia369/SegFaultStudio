var searchData=
[
  ['cheat_5fmenu_0',['cheat_menu',['../main_8c.html#a2b3723559101742ed27e54fb99620911',1,'main.c']]],
  ['count_5fsaves_1',['count_saves',['../save_8h.html#aba955ba7b86394c560634d1d20ade6e1',1,'save.c']]]
];
