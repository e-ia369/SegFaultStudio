var searchData=
[
  ['fight_2ec_0',['fight.c',['../fight_8c.html',1,'']]],
  ['fight_2eh_1',['fight.h',['../fight_8h.html',1,'']]]
];
