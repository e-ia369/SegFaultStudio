var searchData=
[
  ['init_5fhero_0',['init_hero',['../hero_8h.html#a924299a138f1ea64fa4ace836031c711',1,'hero.c']]],
  ['inventory_1',['inventory',['../hero_8h.html#a8935b14e890cb1bfbe8f7759bd3bac87',1,'hero.c']]],
  ['is_5fpadovan_2',['is_padovan',['../fight_8c.html#aa9a1b3abab1e56a604029667cebfe6b9',1,'fight.c']]],
  ['is_5fpadovan_5frec_3',['is_padovan_rec',['../fight_8c.html#a669c395f823adee7b95f06cfd3531efe',1,'fight.c']]]
];
