var fight_8c =
[
    [ "fight", "fight_8c.html#abd4ecd90fd4bf7772bf540aba9131adb", null ],
    [ "is_padovan", "fight_8c.html#aa9a1b3abab1e56a604029667cebfe6b9", null ],
    [ "is_padovan_rec", "fight_8c.html#a669c395f823adee7b95f06cfd3531efe", null ]
];