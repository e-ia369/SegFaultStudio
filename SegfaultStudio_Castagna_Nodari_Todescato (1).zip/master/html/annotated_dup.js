var annotated_dup =
[
    [ "Hero", "structHero.html", null ],
    [ "Save", "structSave.html", null ]
];