Game name: Dungeons and Segfaults

Group name: Segfault Studio
Group size: 3

Members in alphabetic order (by surname):
- Castagna Elia (913570@stud.unive.it)
- Nodari Rossana (909364@stud.unive.it)
- Todescato Tommaso (912156@stud.unive.it)

NOTES:
    - "make game" compiles the game, the binary is not included
    - "make docs" runs doxygen and makes the documentation in "html",
        however docs are already included.
    - The doxygen comments document only the .c files that contain functions which aren't in the .h files
        all the other functions are documented through headers. (for simplicity)
    - /report contains the report .pdf